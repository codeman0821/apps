# AI Screening Chatbot

This is a GitHub-ready repository for your **AI Bootcamp Screening Assistant** chatbot.  
It was generated from your provided source and packaged for easy import to GitHub and deployment via GitHub Pages.

## Quick Start

1. Create a new GitHub repo and upload these files (or use the GitHub **Import repository** flow).
2. Enable **GitHub Pages** (Settings → Pages → Deploy from branch → `main` / `/root`).
3. Open your Pages URL to run the chatbot (it's a static HTML app).

## Files

- `index.html` — self-contained app (HTML/CSS/JS) with Firebase + BroadcastChannel integrations.
- `LICENSE` — MIT license.
- `.gitignore` — ignores OS/editor cruft.

## Firebase

The HTML uses the Firebase SDK includes. If you do not plan to connect to your Firebase project publicly, leave it as-is and the app will run in a limited "offline" mode. **Never commit private keys or secrets**.

## Dashboard Integration

The code posts candidate updates via `BroadcastChannel` to:
```
https://terence1975-coder.github.io/tender/testbot.html
```
Change `dashboardURL` in `index.html` if needed.

## Local development

Just open `index.html` in your browser, or run a tiny server:
```bash
python3 -m http.server 8080
```
Then visit http://localhost:8080/

---

> Generated on 2025-08-21.
